﻿(function () {
    
    function myfunction() {

    }

    function veryLongName() {

    }

    function veryVeryVeryLongName() {

    }

    myfunction();
    veryLongName();
    veryVeryVeryLongName();

})();