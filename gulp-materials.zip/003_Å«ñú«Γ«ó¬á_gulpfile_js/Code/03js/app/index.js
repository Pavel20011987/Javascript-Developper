const a = undefined;
a??7;

const hello = '';
console.log(hello);


