const {series, parallel} = require('gulp');

function tsTojs(cb){
    cb();
}

function minJs(cb){
    cb();
}

function scssToCss(cb){
    cb();
}

function minCss(cb){
    cb();
}

function minImages(cb){
    cb();
}

exports.dev = parallel(tsTojs, scssToCss);

exports.prod = parallel(
    series(tsTojs, minJs),
    series(scssToCss, minCss),
    series(minImages)
);