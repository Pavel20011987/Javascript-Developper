function world(cb){
    console.log('world');
    cb();
}

exports.world = world;