const {series} = require('gulp');
const {world} = require('./moduleA');
function hello(cb){
    console.log('Hello');
    cb();
}

exports.helloworld = series(hello, world);

