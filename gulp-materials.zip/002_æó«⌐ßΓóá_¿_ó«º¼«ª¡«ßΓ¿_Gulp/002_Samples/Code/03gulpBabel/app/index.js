class Foo{
    log(msg){
        console.log(msg);
    }
}