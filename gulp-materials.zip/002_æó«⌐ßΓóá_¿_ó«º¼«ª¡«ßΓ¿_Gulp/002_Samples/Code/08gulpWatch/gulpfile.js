const {watch} = require('gulp');

function style(cb){
    console.log("css changed");
    cb();
}

function script(cb){
    console.log("js changed");
    cb();
}

function watchman(){
    watch('app/*.css',{delay:5000}, style);
    watch('app/*.js', script);
    watch('app/*', {events:'addDir'}, function(cb){
        console.log('New dir');
        cb();
    })
}

exports.watchman=watchman;