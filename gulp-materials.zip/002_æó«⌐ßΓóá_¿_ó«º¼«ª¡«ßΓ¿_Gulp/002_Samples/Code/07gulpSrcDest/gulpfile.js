const {src, dest} = require('gulp');

// function move(){
//     return src('app/index.js')
//     .pipe(dest('dist/'));
// }
// function move(){
//     return src('app/*.js')
//     .pipe(dest('dist/'));
// }
// function move(){
//     return src('app/**/*.js')
//     .pipe(dest('dist/'));
// }
// function move(){
//     return src(['app/lib/*.js','app/*.js'])
//     .pipe(dest('dist/'));
// }
function move(){
    return src(['app/**/*.js','!app/index.js'])
    .pipe(dest('dist/'));
}
exports.move = move;

const babel = require('gulp-babel');

function modjs(){
    return src('app/index.js')
    .pipe(babel({
        presets: ["@babel/preset-env"]
    }))
    .pipe(dest('output/'));
}
exports.modjs = modjs;