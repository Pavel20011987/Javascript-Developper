console.log('hello');
const darkModePreference = null
const getUserDarkModePreference = (darkModePreference) => {
  return darkModePreference ?? true;
}