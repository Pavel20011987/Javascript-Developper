// npm install --save-dev gulp
// npm i gulp-typescript
// npm i @types/gulp
// npm i ts-node
// npm i typescript

import {src, dest} from 'gulp';
import * as ts from 'gulp-typescript';

let isBoolean: boolean = true;

function test(cb){
    console.log(isBoolean);
    cb();
}

exports.test = test;

function tsTojs(){
    return src('app/*.ts')
    .pipe(ts({
        noImplicitAny: true
    }))
    .pipe(dest('dist/'));
}

exports.tstojs = tsTojs;