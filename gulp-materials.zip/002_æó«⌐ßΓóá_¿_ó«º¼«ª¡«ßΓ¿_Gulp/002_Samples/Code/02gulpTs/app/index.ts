function hello(value:string){
    console.log(`Hello form ${value}`);
}